<?php

require_once('headScript.php');
require_once('navbar.php');
require_once('sidebar.php');
require_once('headContent.php');
require_once('content.php');
require_once('footer.php');
require_once('endScript.php');
